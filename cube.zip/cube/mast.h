#include "solidCylinder.h"

void mast(int segments);
