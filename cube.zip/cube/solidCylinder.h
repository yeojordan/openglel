#include "gl.h"

void solidCylinder(double radius, int segments, double length);
