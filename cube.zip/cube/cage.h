#include "solidCylinder.h"

void cage(int segments);
