#include "gl.h"

void axis();
