#include "gl.h"

void rock(int segments);
