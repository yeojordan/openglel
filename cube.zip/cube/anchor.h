#include "gl.h"

void anchor(int segments);
